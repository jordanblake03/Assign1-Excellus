package tests;

import org.junit.jupiter.api.*;
import animals.AnimalType;
import animals.petstore.pet.attributes.Breed;
import animals.petstore.pet.attributes.Gender;
import animals.petstore.pet.attributes.Skin;
import animals.petstore.pet.types.Snake;

import static org.junit.jupiter.api.Assertions.assertEquals;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class SnakeTests {

    private static Snake actualSnake;
    @BeforeAll
    public static void createAnimals()
    {
        actualSnake = new Snake(AnimalType.DOMESTIC, Skin.SCALES, Gender.UNKNOWN, Breed.UNKNOWN);
    }


    @Test
    @Order(1)
    @DisplayName("Animal Test Type Tests Domestic")
    public void animalTypeTests()
    {
        assertEquals(AnimalType.DOMESTIC, actualSnake.getAnimalType(), "Animal Type Expected[" + AnimalType.DOMESTIC
                + "] Actual[" + actualSnake.getAnimalType() + "]");
    }

    @Test
    @Order(1)
    @DisplayName("Snake Speak hiss! hiss! Tests")
    public void snakeGoesHissHissTest()
    {
        assertEquals("The snake goes hiss! hiss!", actualSnake.speak(), "I was expecting: The snake goes hiss! hiss!");
    }

    @Test
    @Order(1)
    @DisplayName("Snake scales are Hyperallergetic")
    public void snakeHyperAllergeticTests()
    {
        assertEquals("The snake is hyperallergetic!", actualSnake.snakeHypoallergenic(),
                "The snake is hypoallergetic!");
    }

    @Test
    @Order(1)
    @DisplayName("Snake has legs Test")
    public void legTests()
    {
        Assertions.assertNotNull(actualSnake.getNumberOfLegs());
    }

    @Test
    @Order(2)
    @DisplayName("SnakeGender Test Male")
    public void genderTestMale()
    {
        actualSnake = new Snake(AnimalType.WILD, Skin.SCALES,Gender.MALE, Breed.BALL_PYTHON);
        assertEquals(Gender.MALE, actualSnake.getGender(), "Expecting Male Gender!");
    }

    @Test
    @Order(2)
    @DisplayName("Snake Breed Test Python")
    public void genderSnakeBreed() {
        actualSnake = new Snake(AnimalType.WILD, Skin.SCALES,Gender.FEMALE, Breed.BALL_PYTHON);
        assertEquals(Breed.BALL_PYTHON, actualSnake.getBreed(), "Expecting Breed Python!");
    }

    @Test
    @Order(2)
    @DisplayName("Snake Speak hiss! hiss! Tests")
    public void snakeGoesHissTest()
    {
        actualSnake = new Snake(AnimalType.WILD, Skin.SCALES,Gender.FEMALE, Breed.BALL_PYTHON);
        assertEquals("The snake goes hiss! hiss!", actualSnake.speak(), "I was expecting hiss! hiss!");
    }
    // Test that tests the setnumberoflegs method
    @Test
    @Order(3)
    @DisplayName("Number of Legs!")
    public void testSetNumberOfLegs() {
        // Instantiate the class under test

        // Test setting a positive number of legs
        actualSnake.setNumberOfLegs(0);
        assertEquals(0, actualSnake.getNumberOfLegs());
    }
    // Test that tests the the typeofpet method
    @Test
    @Order(3)
    public void testTypeOfPet() {
        // Test the typeOfPet method
        assertEquals("The type of pet is SNAKE!", actualSnake.typeOfPet());
    }

    // Test that tests the default speak case method
    @Test
    @Order(3)
    public void testSpeakDefault() {

        // Set the animal type to something other than DOMESTIC or WILD
        actualSnake.setAnimalType(AnimalType.UNKNOWN);

        // Test the speak method
        assertEquals("The snake goes Psss! Psss!", actualSnake.speak());
    }
}

