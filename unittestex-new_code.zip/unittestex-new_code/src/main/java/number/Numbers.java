package number;

/**
 * Numbers class to illustrate the capabilities of a prarameterized test
 */
public class Numbers {
    public static boolean isEven(int number)
    {
        return number %2 ==0;
    }
}
