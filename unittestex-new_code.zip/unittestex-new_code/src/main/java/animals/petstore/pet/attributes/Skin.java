package animals.petstore.pet.attributes;

/**
 * The different types of skin
 */
public enum Skin {
    FUR, HAIR, FEATHERS, SCALES, UNKNOWN;

}
