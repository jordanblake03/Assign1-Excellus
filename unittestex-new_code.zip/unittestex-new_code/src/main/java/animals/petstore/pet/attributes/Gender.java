package animals.petstore.pet.attributes;

/**
 * Pet Gender
 */
public enum Gender {
    MALE, FEMALE, UNKNOWN
}
